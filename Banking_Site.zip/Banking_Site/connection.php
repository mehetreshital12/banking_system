<?php

$username = "root";
$password="";
$server ="localhost";
$db = "bankdb";


$con = mysqli_connect($server,$username,$password,$db);

?>